#include <iostream>
#include <vector>
#include <tuple>
#include <climits>

using namespace std;

const int INF = INT_MAX;

int main()
{
    int V, E, src;

    cout << "Bellman-Ford Algorithm\n";
    cout << "Enter number of vertices, edges, and source vertex: ";
    cin >> V >> E >> src;

    vector<tuple<int, int, int> > edges;

    cout << "\nEnter each edge as: u v w\n";
    cout << "(u = source, v = destination, w = weight)\n\n";

    for (int i = 0; i < E; i++)
    {
        int u, v, w;

        cout << "Edge " << i + 1 << ": ";
        cin >> u >> v >> w;

        edges.push_back(make_tuple(u, v, w));
    }

    vector<int> dist(V, INF);
    dist[src] = 0;

    // Relax edges V-1 times
    for (int i = 0; i < V - 1; i++)
    {
        bool updated = false;

        for (size_t j = 0; j < edges.size(); j++)
        {
            int u = get<0>(edges[j]);
            int v = get<1>(edges[j]);
            int w = get<2>(edges[j]);

            if (dist[u] != INF &&
                dist[u] + w < dist[v])
            {
                dist[v] = dist[u] + w;
                updated = true;
            }
        }

        if (!updated)
            break;
    }

    // Check for negative cycle
    bool hasNegativeCycle = false;

    for (size_t j = 0; j < edges.size(); j++)
    {
        int u = get<0>(edges[j]);
        int v = get<1>(edges[j]);
        int w = get<2>(edges[j]);

        if (dist[u] != INF &&
            dist[u] + w < dist[v])
        {
            hasNegativeCycle = true;
            break;
        }
    }

    cout << "\n===== Bellman-Ford Result =====\n";

    if (hasNegativeCycle)
    {
        cout << "Graph contains a negative-weight cycle reachable from "
             << src << endl;
        return 0;
    }

    cout << "Source Vertex: " << src << "\n\n";

    for (int i = 0; i < V; i++)
    {
        cout << src << " -> " << i << " : ";

        if (dist[i] == INF)
            cout << "Unreachable";
        else
            cout << dist[i];

        cout << endl;
    }

    return 0;
}