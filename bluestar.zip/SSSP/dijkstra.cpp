#include <iostream>
#include <vector>
#include <queue>
#include <climits>

using namespace std;

const int INF = INT_MAX;

int main()
{
    int V, E, src;

    cout << "Enter number of vertices, edges, and source vertex: ";
    cin >> V >> E >> src;

    vector<vector<pair<int, int> > > adj(V);

    cout << "\nEnter each edge as: u v w\n";
    cout << "(u = source vertex, v = destination vertex, w = weight)\n\n";

    for (int i = 0; i < E; i++)
    {
        int u, v, w;

        cout << "Edge " << i + 1 << ": ";
        cin >> u >> v >> w;

        adj[u].push_back(make_pair(v, w));

        // Remove this if the graph is directed
        adj[v].push_back(make_pair(u, w));
    }

    priority_queue<
        pair<int, int>,
        vector<pair<int, int> >,
        greater<pair<int, int> >
    > pq;

    vector<int> dist(V, INF);

    dist[src] = 0;
    pq.push(make_pair(0, src));

    while (!pq.empty())
    {
        int d = pq.top().first;
        int u = pq.top().second;
        pq.pop();

        if (d > dist[u])
            continue;

        for (size_t i = 0; i < adj[u].size(); i++)
        {
            int v = adj[u][i].first;
            int w = adj[u][i].second;

            if (dist[u] != INF &&
                dist[u] + w < dist[v])
            {
                dist[v] = dist[u] + w;
                pq.push(make_pair(dist[v], v));
            }
        }
    }

    cout << "\n===== Dijkstra Result =====\n";
    cout << "Source Vertex: " << src << "\n\n";

    for (int i = 0; i < V; i++)
    {
        cout << src << " -> " << i << " : ";

        if (dist[i] == INF)
            cout << "Unreachable";
        else
            cout << dist[i];

        cout << endl;
    }

    return 0;
}