#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

int knapsack(vector<int>& weight, vector<int>& value, int W)
{
    int n = weight.size();

    vector<vector<int> > dp(
        n + 1,
        vector<int>(W + 1, 0)
    );

    // Build DP table
    for (int i = 1; i <= n; i++)
    {
        for (int w = 0; w <= W; w++)
        {
            dp[i][w] = dp[i - 1][w];

            if (weight[i - 1] <= w)
            {
                int take =
                    dp[i - 1][w - weight[i - 1]]
                    + value[i - 1];

                dp[i][w] = max(dp[i][w], take);
            }
        }
    }

    // Backtrack selected items
    vector<int> chosen;

    int w = W;

    for (int i = n; i >= 1; i--)
    {
        if (dp[i][w] != dp[i - 1][w])
        {
            chosen.push_back(i);
            w -= weight[i - 1];
        }
    }

    reverse(chosen.begin(), chosen.end());

    cout << "\n===== Knapsack Result =====\n";

    cout << "Maximum Value = "
         << dp[n][W] << "\n\n";

    cout << "Selected Items:\n";

    int totalWeight = 0;
    int totalValue = 0;

    for (size_t i = 0; i < chosen.size(); i++)
    {
        int idx = chosen[i];

        cout << "Item " << idx
             << " | Weight = "
             << weight[idx - 1]
             << " | Value = "
             << value[idx - 1]
             << "\n";

        totalWeight += weight[idx - 1];
        totalValue += value[idx - 1];
    }

    cout << "\nTotal Weight = "
         << totalWeight
         << " / "
         << W
         << "\n";

    cout << "Total Value = "
         << totalValue
         << "\n";

    return dp[n][W];
}

int main()
{
    int n;

    cout << "0/1 Knapsack Problem\n";
    cout << "Enter number of items: ";
    cin >> n;

    vector<int> weight(n);
    vector<int> value(n);

    cout << "\nEnter weight and value for each item:\n";

    for (int i = 0; i < n; i++)
    {
        cout << "Item " << i + 1 << ": ";
        cin >> weight[i] >> value[i];
    }

    int W;

    cout << "\nEnter knapsack capacity: ";
    cin >> W;

    knapsack(weight, value, W);

    return 0;
}