#include <iostream>
#include <vector>

using namespace std;

// Returns -1 if amount cannot be formed
int coinChangeMin(vector<int>& coins, int amount)
{
    const int INF = amount + 1;

    vector<int> dp(amount + 1, INF);

    dp[0] = 0;

    for (int a = 1; a <= amount; a++)
    {
        for (size_t i = 0; i < coins.size(); i++)
        {
            int coin = coins[i];

            if (coin <= a &&
                dp[a - coin] + 1 < dp[a])
            {
                dp[a] = dp[a - coin] + 1;
            }
        }
    }

    if (dp[amount] > amount)
        return -1;

    return dp[amount];
}

int main()
{
    int n;

    cout << "Minimum Coin Change Problem\n";
    cout << "Enter number of coin types: ";
    cin >> n;

    vector<int> coins(n);

    cout << "\nEnter coin values:\n";

    for (int i = 0; i < n; i++)
    {
        cin >> coins[i];
    }

    int amount;

    cout << "\nEnter target amount: ";
    cin >> amount;

    int answer = coinChangeMin(coins, amount);

    cout << "\n===== Result =====\n";

    if (answer == -1)
    {
        cout << "Amount cannot be formed using the given coins.\n";
    }
    else
    {
        cout << "Minimum coins required = "
             << answer << "\n";
    }

    return 0;
}