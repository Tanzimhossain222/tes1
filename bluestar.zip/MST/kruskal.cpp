#include <iostream>
#include <vector>
#include <tuple>
#include <algorithm>

using namespace std;

vector<int> parent, sz;

int findSet(int x)
{
    if (parent[x] == x)
        return x;

    return parent[x] = findSet(parent[x]);
}

bool unite(int x, int y)
{
    x = findSet(x);
    y = findSet(y);

    if (x == y)
        return false;

    if (sz[x] < sz[y])
        swap(x, y);

    parent[y] = x;
    sz[x] += sz[y];

    return true;
}

int main()
{
    int V, E;

    cout << "Enter vertices and edges: ";
    cin >> V >> E;

    vector<tuple<int, int, int> > edges;

    for (int i = 0; i < E; i++)
    {
        int u, v, w;
        cout << "Enter edges (u v w):\n";
        cin >> u >> v >> w;

        edges.push_back(make_tuple(w, u, v));
    }

    sort(edges.begin(), edges.end());

    parent.resize(V + 1);
    sz.assign(V + 1, 1);

    for (int i = 1; i <= V; i++)
    {
        parent[i] = i;
    }

    int totalWeight = 0;
    int edgesTaken = 0;

    cout << "MST edges (Kruskal's):\n";

    for (size_t i = 0; i < edges.size(); i++)
    {
        int w = get<0>(edges[i]);
        int u = get<1>(edges[i]);
        int v = get<2>(edges[i]);

        if (unite(u, v))
        {
            totalWeight += w;

            cout << u << " - " << v
                 << " (w = " << w << ")\n";

            edgesTaken++;

            if (edgesTaken == V - 1)
                break;
        }
    }

    cout << "Total weight: " << totalWeight << endl;

    return 0;
}