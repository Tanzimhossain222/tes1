#include <iostream>
#include <vector>
#include <queue>
#include <tuple>

using namespace std;

int main()
{
    int V, E;

    cout << "Prim's Minimum Spanning Tree (MST)\n";
    cout << "Enter number of vertices and edges: ";
    cin >> V >> E;

    vector<vector<pair<int, int> > > adj(V + 1);

    cout << "\nEnter each edge as: u v w\n";
    cout << "(u = vertex 1, v = vertex 2, w = weight)\n\n";

    for (int i = 0; i < E; i++)
    {
        int u, v, w;

        cout << "Edge " << i + 1 << ": ";
        cin >> u >> v >> w;

        adj[u].push_back(make_pair(v, w));
        adj[v].push_back(make_pair(u, w));
    }

    priority_queue<
        tuple<int, int, int>,
        vector<tuple<int, int, int> >,
        greater<tuple<int, int, int> >
    > pq;

    vector<bool> visited(V + 1, false);

    int start = 1;
    int total = 0;
    int edgesTaken = 0;

    visited[start] = true;

    for (size_t i = 0; i < adj[start].size(); i++)
    {
        int v = adj[start][i].first;
        int w = adj[start][i].second;

        pq.push(make_tuple(w, start, v));
    }

    cout << "\n===== MST Edges (Prim's) =====\n";

    while (!pq.empty())
    {
        tuple<int, int, int> edge = pq.top();
        pq.pop();

        int w = get<0>(edge);
        int u = get<1>(edge);
        int v = get<2>(edge);

        if (visited[v])
            continue;

        visited[v] = true;
        total += w;
        edgesTaken++;

        cout << u << " - " << v
             << " (weight = " << w << ")\n";

        for (size_t i = 0; i < adj[v].size(); i++)
        {
            int x = adj[v][i].first;
            int wx = adj[v][i].second;

            if (!visited[x])
            {
                pq.push(make_tuple(wx, v, x));
            }
        }
    }

    if (edgesTaken != V - 1)
    {
        cout << "\nGraph is disconnected.\n";
        cout << "MST cannot be formed.\n";
        return 0;
    }

    cout << "\nTotal MST Weight = "
         << total << endl;

    return 0;
}